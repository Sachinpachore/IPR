package com.harshit.model;

public class AcctDeletionForm {
	private String RID;

	public String getRID() {
		return RID;
	}

	public void setRID(String rID) {
		RID = rID;
	}
}