package com.harshit.model;

public class DeleteConfirmationForm {
	private String selection;

	public String getSelection() {
		return selection;
	}

	public void setSelection(String selection) {
		this.selection = selection;
	}
}